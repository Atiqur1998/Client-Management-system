 <footer>
            <p>Client Management System</p>
        </footer>